/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockrmiserverproject;


import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author haonan
 */
public class StockRMIServant extends UnicastRemoteObject implements StockRMI{
    /* Given a stock, get a list of users that are interested in that stock.*/
    //I use Set<String> to store users' name,so no name will be repeatly recorded.
  
    private static Map<String,Set<String>> stocks = new TreeMap<>();
    /* Given a user, get the remote object reference to its callback method. */
    private static Map<String, Notifiable> users = new TreeMap<>();
    
    StockRMIServant() throws RemoteException{

    }
    /**Subscribe
     * put a client in into a stock's list he/she is interested in.
     * 
     * @param user
     * @param stockSym
     * @return
     * @throws RemoteException 
     */
    @Override
    public boolean subscribe(String user, String stockSym) throws RemoteException {
        if(stocks.get(stockSym)==null){
            System.out.println("Stock "+stockSym+" is not in our System");
            return false;
        }else{
            //I use Set<String> to store users' name,so no name will be repeatly recorded.
            stocks.get(stockSym).add(user);
            return true;
        }
    }

    /**UnSubscribe
     * 
     * @param user
     * @param stockSym
     * @return
     * @throws RemoteException 
     */
    @Override
    public boolean unSubscribe(String user, String stockSym) throws RemoteException {
        //no such stock
        if(stocks.get(stockSym)==null){
            System.out.println("Stock "+stockSym+" is not in our System");
            return false;
        }else{
            //the user was not interested in this stock before
            if(!stocks.get(stockSym).contains(user)){
                System.out.println("User "+user+" does not subscribe this stock");
                return false;
            }
            else {
                stocks.get(stockSym).remove(user);
                System.out.println("User "+user+" doesn't subscribe to the stock of "+stockSym+" any more");
            }
       }
       return true;
    }

    /**StockUpdate
     * this method notify users the price of a stock
     * if the stock doesn't exist,create and add it into stocks
     * @param stockSym
     * @param price
     * @throws RemoteException 
     */
    @Override
    public void stockUpdate(String stockSym, double price) throws RemoteException {
        //the stock exists
        if(stocks.get(stockSym)!=null){
            //get the set of users of this stock
            Set<String> userSet = stocks.get(stockSym);
            //notice every user
            for(String user:userSet){
                Notifiable notice = users.get(user);
                notice.notify(stockSym, price);
                System.out.println("Notify user: "+ user);
            }
        }else{
            //add this stock into map stocks with empty user set
            Set newset= new HashSet<>();
            stocks.put(stockSym,newset);
        }
    }

    /**RegisterCallBack & DeRegisterCallBack
     * first method will add user to the stocks.when the price of the stock changes,the user will be notified.
     * second method do the opposite thing.
     * @param remoteClient
     * @param user
     * @throws RemoteException 
     */
    @Override
    public void registerCallBack(Notifiable remoteClient, String user) throws RemoteException {
        if(users.get(user)==null){
            users.put(user, remoteClient);
        }else{
            //if the user already exists, update the remoteClient
            users.replace(user, remoteClient);
        }
        
    }

    @Override
    public void deRegisterCallBack(String user) throws RemoteException {
        Notifiable notice=users.get(user);
        if(notice !=null){
            notice.exit();
            users.remove(user);
        }

        
    }
    
}
