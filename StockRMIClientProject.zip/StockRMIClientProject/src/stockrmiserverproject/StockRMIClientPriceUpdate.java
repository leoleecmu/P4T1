package stockrmiserverproject;

import java.rmi.Naming;
import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author haonan
 */

/**
 *  interacts with a user at the keyboard. The user enters lines of text in the following format: 
 * <stockSym> <price> or <!> to quit. 
 * @author haonan
 */
public class StockRMIClientPriceUpdate {
    
    public static void main(String[] args) throws Exception {

        System.out.println("Enter stock symbol and price or ! to quit.");
        //get input
        Scanner sc = new Scanner(System.in);        
        // connect to the rmiregistry and get a remote reference to the StockRMI object.
        StockRMI sr  = (StockRMI) Naming.lookup("//localhost/stockService");
        
        while (true){
            String line = sc.nextLine();
            //if enter "!" then quit
            if(line.equals("!")){
                System.exit(0);
            }
            if(!line.equals("")){
                //seperate the input line when it is not empty
                StringTokenizer st = new StringTokenizer(line);
                String stockName = st.nextToken();
                String stockPrice = st.nextToken();    
                double price = Double.parseDouble(stockPrice);
                //update the stock price by calling the method stockUpdate
                sr.stockUpdate(stockName, price);
            }           
        }
    }
}
