/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockrmiserverproject;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

/**
 *
 * @author haonan
 */

/**
 * When the main routine of this class runs, it will prompt the
user for a user name and then it will perform a lookup on the registry and will call the
registerCallBack method on the stock service. The signature of the registerCallBack
method is shown below. At that point, the server will have a remote reference to the
client’s callback methods
 * @author haonan
 */
public class StockPriceCallBack extends UnicastRemoteObject implements Notifiable {


    public StockPriceCallBack() throws RemoteException {
    }
    @Override
    public void notify(String stockSym, double price) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         //System.out.println(stockSym + ": $" + price);
    }

    @Override
    public void exit() throws RemoteException{
        try{
            UnicastRemoteObject.unexportObject(this, true);
            System.out.println("StockPriceCallBack exiting.");
        }catch(Exception e){ 
            System.out.println("Exception thrown" + e);
        }
    }

    public static void main(String[] args)throws Exception {
        
        
        //get input user name
        System.out.println("Enter user name: ");
        Scanner sc = new Scanner(System.in);
        String userName = sc.nextLine();
        

        // connect to the rmiregistry
        System.out.println("Looking up the server in the registry");  
        StockRMI sr  = (StockRMI) Naming.lookup("//localhost/stockService");
        //StockRMI sr  = (StockRMI) Naming.lookup("//localhost/stockService");        

        System.out.println("Creating a callback object to handle calls from the server.");
        Notifiable notice = new StockPriceCallBack();

        System.out.println("Registering the callback with a name at the server.");
        sr.registerCallBack(notice, userName);
        System.out.println("Callback handler for StockDealer ready.");



    }
    
}