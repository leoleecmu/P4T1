/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockrmiserverproject;

import java.rmi.Naming;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author haonan
 */
/**
 * This class will also prompt for a user name and interact
with a user at the keyboard. The user will enter lines in the following format: “S
<stockSym>” or “U <stockSym>” or “<!>” to quit
 * @author haonan
 */
public class StockRMIClientSubscription {
    public static void main(String[] args) throws Exception{
        //get input
        System.out.print("Enter user name: ");
        Scanner sc = new Scanner(System.in);
        String userName = sc.nextLine();
        System.out.println("Hello " + userName);  
        System.out.println("Enter stock symbol and price or ! to quit.");
        
        // connect to the rmiregistry and get a remote reference to the StockRMI object.
        StockRMI sr  = (StockRMI) Naming.lookup("//localhost/stockService");
        while (true){
            String line = sc.nextLine();
            //if enter "!" then quit
            if(line.equals("!")){
                System.exit(0);
            }
            if(!line.equals("")){
                //seperate the input line when it is not empty
                StringTokenizer st = new StringTokenizer(line);
                String operation = st.nextToken();
                String stockName = st.nextToken(); 
                //S means subscribe
                if(operation.equals("S")){
                    sr.subscribe(userName, stockName);
                }
                //U means unsubscribe
                if(operation.equals("U")){
                    sr.unSubscribe(userName, stockName);
                }

            }
            
        }
    }
}
